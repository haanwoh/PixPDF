# Publish PixPDF to haanwoh/PixPDF

The Vercel project `pixpdf-haanwoh` is connected to `https://github.com/haanwoh/PixPDF`. The repository was empty when checked, so Vercel has no commit to build yet.

After extracting this source archive, run these commands in the extracted folder. GitHub will prompt you to authenticate using your own account credentials:

```sh
git init -b main
git add .
git commit -m "Publish PixPDF tools and fixes"
git remote add origin https://github.com/haanwoh/PixPDF.git
git push -u origin main
```

Vercel is configured to run `npm ci`, `npm run build`, and publish `dist`. The first push to `main` should trigger the deployment.
