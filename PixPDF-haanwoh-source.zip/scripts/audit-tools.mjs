import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import { tools } from "../src/data/tools.js";

const registry = await readFile(new URL("../src/tools/registry.js", import.meta.url), "utf8");
const modulePaths = new Map(
  [...registry.matchAll(/"([^"]+)":\s*\(\)\s*=>\s*import\("(\.\/[^\"]+)"\)/g)]
    .map((match) => [match[1], new URL(`../src/tools/${match[2].replace(/^\.\//, "")}`, import.meta.url).pathname])
);
assert.equal(new Set(tools.map(({ slug }) => slug)).size, tools.length, "tool slugs must be unique");
const failures = [];
for (const tool of tools) {
  const path = modulePaths.get(tool.slug);
  if (!path || !existsSync(path)) {
    failures.push(`${tool.slug}: missing registry entry or implementation file`);
    continue;
  }
  const source = await readFile(path, "utf8");
  if (!/export\s+default\s*\{/.test(source) && !/export\s+\{[^}]*\bas\s+default/.test(source)) {
    failures.push(`${tool.slug}: no default tool implementation`);
  }
  if (!/\b(process|mount)\s*\(/.test(source)) {
    failures.push(`${tool.slug}: no process() or mount() handler`);
  }
  for (const option of tool.options) {
    if (!option.key || option.default === undefined) failures.push(`${tool.slug}: invalid option ${option.key}`);
    if (["select", "choice"].includes(option.type) && !option.choices?.length) {
      failures.push(`${tool.slug}: ${option.key} has no choices`);
    }
  }
}
assert.deepEqual(failures, [], failures.join("\n"));
console.log(`Audited ${tools.length} tools: registry entries, implementation modules, handlers and option schemas are present.`);
