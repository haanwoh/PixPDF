import { defineConfig } from "vite";

export default defineConfig({
  build: {
    manifest: "manifest.json"
  },
  server: {
    host: "0.0.0.0",
    allowedHosts: true
  },
  preview: {
    host: "0.0.0.0",
    allowedHosts: true
  }
});
